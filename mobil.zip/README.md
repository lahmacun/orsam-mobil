# front-end-starter


Git clone and npm run build > npm install and gulp run
