$(function() {
  $('.mobile-menu li a').on('click', function(e) {
    if ($(this).parent().find('.dropdown-menu').length) {
      e.preventDefault();
      $(this).parent().find('> .dropdown-menu').stop().toggle();
    }
    return;
  });

  $('.mobile-menu li a').on('dblclick', function(e) {
    window.location.href = $(this).attr('href');
  });

  $('.mobile-toggler').on('click', function(e) {
    e.preventDefault();
    $('.mobile-menu').stop().toggle();
  });

  $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
      0:{
        items:1
      },
      600:{
        items:1
      },
      1000:{
        items:1
      }
    }
  });

  $('.section-carousel').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    responsive:{
      0:{
        items:1
      },
      450:{
        items:2
      },
      1000:{
        items:3
      }
    }
  });

  $('.bulletin-carousel').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    responsive:{
      0:{
        items:1
      },
      450:{
        items:2
      },
      1000:{
        items:3
      }
    }
  });
});
